SK PIXEL WEBSITE - LIVE KARNE KI GUIDE (free)

STEP 1: Apna link (domain) tay karein
  Free hosting par aap ko ek link milta hai, jaise  https://skpixel.pages.dev  ya  https://skpixel.vercel.app
  Pehle hosting par upload karein (neeche dekhein), link mil jaye to Step 2 karein.

STEP 2: YOUR-SITE.com ko apne asli link se badalna (SEO ke liye zaroori)
  In 3 files ko Notepad mein kholein:  index.html, robots.txt, sitemap.xml
  Notepad mein Ctrl+H dabayen.
  Find:  https://YOUR-SITE.com      Replace with:  https://aapka-asli-link   (end mein / na lagayen)
  "Replace All" dabayen aur save karein. Phir dobara upload karein.

STEP 3: Upload (koi ek chunein)
  A) Cloudflare Pages (meri pehli raaye): dash.cloudflare.com > Workers & Pages > Create > Pages > Upload assets.
     Is zip ko extract karke poora folder upload karein. Free, tez, HTTPS.
  B) Vercel: vercel.com par account banayen. Add New > Project ke baad folder upload karna ho to Vercel CLI
     chahiye hoti hai; asaan tareeqa GitHub se jodna hai (github.com par repository banayen, files upload karein,
     phir Vercel mein import karein).
  C) Netlify Drop: app.netlify.com/drop par folder drag karein. Sab se asaan.
  D) InfinityFree: File Manager > htdocs mein saari files upload karein (index.html seedha htdocs mein ho).
     Yeh tez nahi hoti aur kabhi kabhi apne ads/scripts daal sakti hai, is liye A ya C behtar hain.

STEP 4: Google mein dikhane ke liye
  1. search.google.com/search-console par jayen, "URL prefix" mein apna link daalein.
  2. Verification ke baad Sitemaps mein  sitemap.xml  submit karein.
  3. "URL Inspection" mein apna link daal kar "Request indexing" dabayen.
  Google mein aane mein kuch din se hafte lag sakte hain. Bing ke liye bing.com/webmasters par yahi karein.

STEP 5: Baad mein links add karna
  index.html mein social icons ke links href="#" data-pending hain. Asli link daalte waqt data-pending hata dein.

Files:
  index.html, style.css, script.js   - website
  images/                            - saari images
  resources/                         - Student Hub ke 3 pages
  404.html, robots.txt, sitemap.xml  - SEO aur errors
  _headers (Cloudflare/Netlify), vercel.json (Vercel), .htaccess (InfinityFree) - speed aur safety
